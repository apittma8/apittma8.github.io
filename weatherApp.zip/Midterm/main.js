let latitude = 52.52;
let longitude = 13.41;
async function getLocation() {
    if (latitude != 52.52) {
        update({
            coords: {
                latitude: latitude,
                longitude: longitude
            }
        })
    } else {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(update, showError);
        }
    }
};

function showError(error) {
  update(undefined, error);
};

let measure = "°F";
let unit = "fahrenheit";
async function changeUnit() {
    if (unit == "fahrenheit") {
        unit = "celsius";
        measure = "°C";
    } else {
        unit = "fahrenheit";
        measure = "°F";
    };
    getLocation();
};

function getDirection(degrees) {
    const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    const normalized = (degrees % 360 + 360) % 360;
    const index = Math.round(normalized / 45) % 8;

    return directions[index];
}

function getIcon(number) {
    console.log(number);
    if (number == 0) {
        return "weatherIcons/sunny.svg";
    } else if (number > 1 && number < 13) {
        return "weatherIcons/cloudy.svg";
    } else if (number > 19 & number < 30) {
        return "weatherIcons/rainy.svg";
    } else if (number > 29 & number < 50) {
        return "weatherIcons/cloudy.svg";
    } else if (number > 49 & number < 70) {
        return "weatherIcons/rainy.svg";
    } else if (number > 69 & number < 80) {
        return "weatherIcons/snowing.svg";
    } else if (number > 79 & number < 90) {
        return "weatherIcons/rainy.svg";
    } else if (number > 89) {
        return "weatherIcons/thundering.svg";
    };
    return "weatherIcons/sunny.svg";
};

const weekday = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
async function update(position, error) {
    if (position) {
        latitude = position.coords.latitude;
        longitude = position.coords.longitude;
    } else if (error.code == error.PERMISSION_DENIED) {
        document.getElementById("error").innerHTML = "User denied the request for Geolocation.";
        return
    } else {
        document.getElementById("error").innerHTML = error.code;
    }
    let url = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&timeformat=unixtime&timezone=auto&daily=weather_code,temperature_2m_min,temperature_2m_max&hourly=temperature_2m,wind_speed_10m,weather_code&current=temperature_2m,wind_speed_10m,wind_direction_10m,weather_code&wind_speed_unit=mph&temperature_unit=${unit}&precipitation_unit=inch`;
    let request = await fetch(url, {
        method: "GET"
    });
    let result = await request.json();
    let currentTime = new Date(result.current.time * 1000);
    document.getElementById("currentTemp").innerHTML = `${result.current.temperature_2m}${measure} ${currentTime.toLocaleString("en-US", {hour12:false, hour: '2-digit', minute:'2-digit'})}`;
    document.getElementById("currentTempHot").innerHTML = `${result.daily.temperature_2m_max[0]}${measure} (Highest)`;
    document.getElementById("currentTempCold").innerHTML = `${result.daily.temperature_2m_min[0]}${measure} (Lowest)`;
    document.getElementById("currentWeatherIcon").src = getIcon(result.current.weather_code);
    console.log(result);

    let hourlyTemps = document.getElementsByClassName("hourlyTemp");
    let lowest = 999999;
    let highest = -999999;
    let startingDigit = 0;
    for (let i = 0; i < 30; i++) {
        if (result.hourly.time[i] == Math.floor((result.current.time+3600)/3600)*3600) {
            startingDigit = i;
        };
    }
    for (let i = startingDigit; i < startingDigit + 7; i++) {
        if (lowest > result.hourly.temperature_2m[i]) {
            lowest = result.hourly.temperature_2m[i];
        }
        if (highest < result.hourly.temperature_2m[i]) {
            highest = result.hourly.temperature_2m[i];
        }
    }

    for (let i = startingDigit; i < startingDigit + 7; i++) {
        let date = new Date(result.hourly.time[i] * 1000);
        hourlyTemps[i-startingDigit].innerHTML = `
        <div class="bar" style="height:${(((result.hourly.temperature_2m[i] - lowest) / (highest-lowest)) * 150) + 10}px"></div>
        <p>${result.hourly.temperature_2m[i]}${measure}</p>
        <p>${date.toLocaleString("en-US", {hour12:true, hour: '2-digit', minute:'2-digit'})}</p>
        <img src="${getIcon(result.hourly.weather_code[i])}" alt="">`;
    }

    let dailyTemps = document.getElementsByClassName("dailyTemp");
    let lowestDaily = 999999;
    let highestDaily = -999999;
    for (let i = 0; i < 7; i++) {
        let average = (result.daily.temperature_2m_min[i] + result.daily.temperature_2m_max[i])/2
        if (lowestDaily > average) {
            lowestDaily = average;
        }
        if (highestDaily < average) {
            highestDaily = average;
        }
    }

    for (let i = 0; i < 7; i++) {
        let date = new Date(result.daily.time[i] * 1000);
        let average = (result.daily.temperature_2m_min[i] + result.daily.temperature_2m_max[i])/2
        dailyTemps[i].innerHTML = `
        <div class="bar" style="height:${(((average - lowestDaily) / (highestDaily-lowestDaily)) * 150) + 10}px"></div>
        <p class="tempHot">${result.daily.temperature_2m_max[i]}${measure}</p>
        <p class="tempCold">${result.daily.temperature_2m_min[i]}${measure}</p>
        <p>${weekday[date.getDay()]}</p>
        <img src="${getIcon(result.daily.weather_code[i])}" alt="">`;
    }

    document.getElementById("windDisplay").innerHTML = `
    <h2>Wind Direction:<br>${getDirection(result.current.wind_direction_10m)}</h2>
    <h2>Wind Speed:<br>${result.current.wind_speed_10m}mp/h</h2>`
};

getLocation();